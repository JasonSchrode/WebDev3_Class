$(function() {

	$('.hamburger').on('click', function() {
		$('.drawer').toggleClass('open');
	});

	$('.hamburger').on('click', function() {
		$('.hamburger--spin').toggleClass('is-active');
	});


});