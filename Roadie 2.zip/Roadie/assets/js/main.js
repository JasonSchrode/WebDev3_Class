$(function() {

	$('.hamburger').on('click', function() {
		$('.drawer').toggleClass('open');
	});

	$('.hamburger').on('click', function() {
		$('.hamburger--spin').toggleClass('is-active');
	});



	$('.nav-link').click(function() {
		$('.nav-link').removeClass('show');
		$(this).addClass('show');
	});


	$('.back-to-top').on('click', function(){
		$.scrollTo($('.landing'), 400);
	});


	$('.spinning-logo').on('click', function() {
		$.scrollTo($('.home-page'), 400);
	});


});