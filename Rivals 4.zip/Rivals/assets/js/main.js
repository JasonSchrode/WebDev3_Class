$(document).ready (function() {


	$('.select-messi').click(function(){

		$('.active-rival-group').removeClass('show');
		$('.active-rival-group').eq( $(this).index('.active-rival-group')).addClass('show');

		$('.active-awards-group.cristy').removeClass('show');
		$('.active-awards-group.messi').addClass('show');

		$('.select-messi').addClass('messi-show');
		$('.select-cristy').removeClass('show');

		$('.cristy').removeClass('show');
		$('.messi').addClass('messi-bg');

	});



	$('.select-cristy').click(function(){

		$('.active-rival-group').addClass('show');
		$('.active-rival-group').eq( $(this).index('.active-rival-group')).removeClass('show');
	

		$('.active-awards-group.cristy').addClass('show');
		$('.active-awards-group.messi').removeClass('show');

		$('.select-messi').removeClass('messi-show');
		$('.select-cristy').addClass('show');

		$('.cristy').addClass('show');
		$('.messi').removeClass('messi-bg');

	});






});