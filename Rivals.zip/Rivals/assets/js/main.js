$(document).ready (function() {


	$('.rival-select').click(function(){

		$('.active-rival-group').removeClass('show');
		$('.active-rival-group').eq( $(this).index('.active-rival-group')).addClass('show');

	});
	











});