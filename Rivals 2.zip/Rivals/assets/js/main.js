$(document).ready (function() {


	$('.select-messi').click(function(){

		$('.active-rival-group').removeClass('show');
		$('.active-rival-group').eq( $(this).index('.active-rival-group')).addClass('show');

	});

	
	$('.select-cristy').click(function(){

		$('.active-rival-group').addClass('show');
		$('.active-rival-group').eq( $(this).index('.active-rival-group')).removeClass('show');
	});


	$('.select-messi').click(function(){


		$('.select-messi').addClass('fill');
		$('.select-messi').eq( $(this).index('.select-messi')).removeClass('fill');

	});










});